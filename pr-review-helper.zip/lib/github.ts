import { Octokit } from "@octokit/rest"

// Initialize Octokit with GitHub token
const octokit = new Octokit({
  auth: process.env.GITHUB_TOKEN,
})

/**
 * Fetch open pull requests from a GitHub repository
 */
export async function fetchPullRequests(owner: string, repo: string) {
  try {
    const response = await octokit.pulls.list({
      owner,
      repo,
      state: "open",
      sort: "updated",
      direction: "desc",
    })

    return response.data
  } catch (error) {
    console.error("Error fetching pull requests:", error)
    throw new Error("Failed to fetch pull requests")
  }
}

/**
 * Fetch the files changed in a pull request
 */
export async function fetchPullRequestFiles(owner: string, repo: string, pullNumber: number) {
  try {
    const response = await octokit.pulls.listFiles({
      owner,
      repo,
      pull_number: pullNumber,
    })

    return response.data
  } catch (error) {
    console.error("Error fetching PR files:", error)
    throw new Error("Failed to fetch PR files")
  }
}

/**
 * Post a comment to a pull request
 */
export async function postCommentToPR(owner: string, repo: string, pullNumber: number, comment: string) {
  try {
    await octokit.issues.createComment({
      owner,
      repo,
      issue_number: pullNumber,
      body: comment,
    })

    return true
  } catch (error) {
    console.error("Error posting comment to PR:", error)
    throw new Error("Failed to post comment to PR")
  }
}

/**
 * Get the content of a file from a specific branch
 */
export async function getFileContent(owner: string, repo: string, path: string, ref: string) {
  try {
    const response = await octokit.repos.getContent({
      owner,
      repo,
      path,
      ref,
    })

    // @ts-ignore - The response type is complex and can vary
    const content = Buffer.from(response.data.content, "base64").toString()
    return content
  } catch (error) {
    console.error(`Error fetching file content for ${path}:`, error)
    return null
  }
}
