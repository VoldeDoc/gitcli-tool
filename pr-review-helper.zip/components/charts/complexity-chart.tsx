"use client"

import { useEffect, useState } from "react"
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts"
import { Card } from "@/components/ui/card"

interface ComplexityChartProps {
  repositoryId: string
  days: number
}

export function ComplexityChart({ repositoryId, days }: ComplexityChartProps) {
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        // In a real app, you would fetch this data from your API
        // const response = await fetch(`/api/metrics/complexity?repositoryId=${repositoryId}&days=${days}`)
        // const result = await response.json()
        // setData(result.data)

        // For demo purposes, we'll generate mock data
        const mockData = generateMockData(days, repositoryId)
        setData(mockData)
      } catch (error) {
        console.error("Error fetching complexity data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [repositoryId, days])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">Loading chart data...</p>
      </div>
    )
  }

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">No data available for the selected time range</p>
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <XAxis
          dataKey="date"
          tickFormatter={(value) => new Date(value).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
          stroke="#888888"
          fontSize={12}
        />
        <YAxis domain={[0, 100]} stroke="#888888" fontSize={12} tickFormatter={(value) => `${value}`} />
        <Tooltip
          content={({ active, payload }) => {
            if (active && payload && payload.length) {
              return (
                <Card className="p-2 border shadow-sm bg-background">
                  <div className="text-xs">
                    <p className="font-medium">{new Date(payload[0].payload.date).toLocaleDateString()}</p>
                    <p>Complexity: {payload[0].value}</p>
                  </div>
                </Card>
              )
            }
            return null
          }}
        />
        <Line
          type="monotone"
          dataKey="complexity"
          stroke="#f97316"
          strokeWidth={2}
          dot={{ r: 1 }}
          activeDot={{ r: 4 }}
        />
      </LineChart>
    </ResponsiveContainer>
  )
}

// Helper function to generate mock data
function generateMockData(days: number, repositoryId: string) {
  const data = []
  const today = new Date()

  // Use repository ID to generate consistent but different data for each repo
  const repoSeed = repositoryId.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0)

  // Start with a base complexity between 30-50
  let complexity = 40 + (repoSeed % 10)

  for (let i = days; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)

    // Add some random variation to the complexity
    const variation = Math.sin(i * 0.2) * 4 + (Math.random() * 5 - 2.5)
    complexity = Math.max(0, Math.min(100, complexity + variation))

    data.push({
      date: date.toISOString(),
      complexity: Math.round(complexity),
    })
  }

  return data
}
